window.onload
{
    alert("Hello TEJ");
}

var data = 0;

document.getElementById('qty1').innerText = data;

function incrementQty1()
{
  data = data+1;
  document.getElementById('qty1').innerText = data;
}

function decrementQty1()
{
    if(data>0)
    {
      data = data-1;
      document.getElementById('qty1').innerText = data;
    }
    
}

var data2 = 0;

document.getElementById('qty2').innerText = data;

function incrementQty2()
{
  data2 = data2+1;
  document.getElementById('qty2').innerText = data2;
}

function decrementQty2()
{
  if(data2>0)
  {
    data2 = data2-1;
    document.getElementById('qty2').innerText = data2;
  }
    
}

function grandTotal()
{
  var p1=parseInt(document.getElementById('price1').value);
  var q1=parseInt(document.getElementById('qty1').innerText);
  var total1=p1*q1;
  document.getElementById('total1').innerText = total1;

  var p2=parseInt(document.getElementById('price2').value);
  var q2=parseInt(document.getElementById('qty2').innerText);
  var total2=p2*q2;
  document.getElementById('total2').innerText = total2;

  var Total=total1+total2;
  document.getElementById('totalprice').innerText=Total;

  var vat = Total * 0.13;
  document.getElementById('vat').innerText = vat;

  var tip = Total * 0.1;
  document.getElementById('tip').innerText = tip;

  var grandTotal = Total + vat + tip;
  document.getElementById('grandtotal').innerText = grandTotal;
}